
$(document).ready(function(){

	window.sr = ScrollReveal({ reset: true });
	var firstTime = true;

	sr.reveal('#toolbar', {
		duration: 200,
		origin: 'top',
		distance: '500px',
		easing: 'ease-in-out',
		opacity: 0
	});

	sr.reveal('#sub_tool_bar', {
		duration: 200,
		origin: 'top',
		distance: '500px',
		easing: 'ease-in-out',
		opacity: 0
	});


	setInterval(
		function() {
			console.log($("#team_member_div").scrollLeft());
			if ($(document).scrollTop() >= 20) {
		    	$("#toolbar").css({"top": "-100px"});
		    	$("#sub_tool_bar").css({"top": "0px"});
			} else {
			    	$("#toolbar").css({"top": "0px"});
			    	$("#sub_tool_bar").css({"top": "70px"});
			}

			if ($(document).scrollTop() <= 200) {
				$("#menu_item_1").addClass("underline");
				$("#menu_item_2").removeClass("underline");
				$("#menu_item_3").removeClass("underline");
				$("body").removeClass("changeBack1");
				$("body").addClass("changeBack2");
				$("body").removeClass("changeBack3");
				$(".team").removeClass("opacity");
			} else if ($(document).scrollTop() > 200 && $(document).scrollTop() < 770){
				$("#menu_item_2").addClass("underline");
				$("#menu_item_1").removeClass("underline");
				$("#menu_item_3").removeClass("underline");
				
				$("body").addClass("changeBack1");
				$("body").removeClass("changeBack2");
				$("body").removeClass("changeBack3");
				$(".team").addClass("opacity");
			} else {
				$("#menu_item_3").addClass("underline");
				$("#menu_item_2").removeClass("underline");
				$("#menu_item_1").removeClass("underline");
				$("body").removeClass("changeBack2");
				$("body").addClass("changeBack3");
				$("body").removeClass("changeBack1");
			}
		}, 
		200);

});